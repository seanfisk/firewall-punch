#!/bin/sh
java -jar fp_client.jar $*
