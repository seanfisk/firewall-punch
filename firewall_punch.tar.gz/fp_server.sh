#!/bin/sh
java -jar fp_server.jar $*
